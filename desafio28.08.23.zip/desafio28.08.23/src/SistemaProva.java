import java.util.Scanner;

public class SistemaProva {
    public static void main(String[] args){
        Prova prova = new Prova();
        Scanner scanner = new Scanner(System.in);




        prova.definirQuestao1(new Questao("Quem criou a Bomba de Nagasaki?",
                new String[]{"Batman", "Super Homem", "Oppenheimer", "Coringa"}, 2));
        prova.definirQuestao2(new Questao("Qual a raiz quadrada de 144?",
                new String[]{"13", "12", "11", "10"}, 1));
        prova.definirQuestao3(new Questao("Quem criou a Bomba de Nagasaki?",
                new String[]{"Batman", "Super Homem", "Oppenheimer", "Coringa"}, 2));
        prova.definirQuestao4(new Questao("Quem criou a Bomba de Nagasaki?",
                new String[]{"Batman", "Super Homem", "Oppenheimer", "Coringa"}, 2));
        prova.definirQuestao5(new Questao("Quem criou a Bomba de Nagasaki?",
                new String[]{"Batman", "Super Homem", "Oppenheimer", "Coringa"}, 2));
        prova.definirQuestao6(new Questao("Quem criou a Bomba de Nagasaki?",
                new String[]{"Batman", "Super Homem", "Oppenheimer", "Coringa"}, 2));
        prova.definirQuestao7(new Questao("Quem criou a Bomba de Nagasaki?",
                new String[]{"Batman", "Super Homem", "Oppenheimer", "Coringa"}, 2));
        prova.definirQuestao8(new Questao("Quem criou a Bomba de Nagasaki?",
                new String[]{"Batman", "Super Homem", "Oppenheimer", "Coringa"}, 2));
        prova.definirQuestao9(new Questao("Quem criou a Bomba de Nagasaki?",
                new String[]{"Batman", "Super Homem", "Oppenheimer", "Coringa"}, 2));
        prova.definirQuestao10(new Questao("Quem criou a Bomba de Nagasaki?",
                new String[]{"Batman", "Super Homem", "Oppenheimer", "Coringa"}, 2));



        Questao[] questoes = prova.getQuestoes();

        int pontuacao = 0;
        for (int i = 0; i < questoes.length; i++) {
            System.out.println("Questão " + (i + 1) + ": " + questoes[i].getEnunciado());
            System.out.print("Sua resposta (1, 2,3 ou 4): ");
            int resposta = scanner.nextInt();

            if (resposta >= 1 && resposta <= 4) {
                if (resposta == questoes[i].getGabarito()) {
                    System.out.println("Resposta certa");
                    pontuacao++;
                } else {
                    System.out.println("Resposta incorreta. A resposta correta era: " + questoes[i].getGabarito());
                }
        }
    System.out.println("Sua nota: " + pontuacao + " de " + questoes.length);
}
        }}