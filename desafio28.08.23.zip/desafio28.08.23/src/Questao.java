public class Questao {
    private String enunciado;
    private String[] alternativas;
    private int gabarito;

    public Questao(String enunciado, String[] alternativas, int gabarito) {
        this.enunciado = enunciado;
        this.alternativas = alternativas;
        this.gabarito = gabarito;
    }
    public String getEnunciado() {
        return enunciado;
    }

    public String[] getAlternativas() {
        return alternativas;
    }

    public int getGabarito() {
        return gabarito;
    }
}
