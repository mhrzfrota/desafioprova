public class Prova {
    private Questao[] questoes;

    public Prova() {
        questoes = new Questao[10];
    }

    public Questao[] getQuestoes() {
        return questoes;
    }

    public void definirQuestao1(Questao questao) {
        questoes[0] = questao;
    }
    public void definirQuestao2(Questao questao) {
        questoes[1] = questao;
    }
    public void definirQuestao3(Questao questao) {
        questoes[2] = questao;
    }
    public void definirQuestao4(Questao questao) {
        questoes[3] = questao;
    }
    public void definirQuestao5(Questao questao) {
        questoes[4] = questao;
    }
    public void definirQuestao6(Questao questao) {
        questoes[5] = questao;
    }
    public void definirQuestao7(Questao questao) {
        questoes[6] = questao;
    }
    public void definirQuestao8(Questao questao) {
        questoes[7] = questao;
    }
    public void definirQuestao9(Questao questao) {
        questoes[8] = questao;
    }
    public void definirQuestao10(Questao questao) {
        questoes[9] = questao;
    }
}
